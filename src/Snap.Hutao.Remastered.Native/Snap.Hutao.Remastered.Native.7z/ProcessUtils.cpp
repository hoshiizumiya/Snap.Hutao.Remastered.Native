#pragma once

#include "ProcessUtils.h"
#include <TlHelp32.h>
#include <Windows.h>
#include <wchar.h>
#include <string.h>

// ��ȡ���̵����߳�ID������ʱ��������̣߳�
DWORD GetMainThreadId(DWORD processId)
{
    DWORD mainThreadId = 0;
    ULONGLONG minCreateTime = ~(ULONGLONG)0; // ������ֵ

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }

    THREADENTRY32 te32;
    te32.dwSize = sizeof(THREADENTRY32);

    if (Thread32First(hSnapshot, &te32)) {
        do {
            if (te32.th32OwnerProcessID == processId) {
                // ���߳̾���Ի�ȡ����ʱ��
                HANDLE hThread = OpenThread(
                    THREAD_QUERY_INFORMATION,
                    FALSE,
                    te32.th32ThreadID);

                if (hThread) {
                    FILETIME createTime, exitTime, kernelTime, userTime;
                    if (GetThreadTimes(hThread, &createTime, &exitTime,
                        &kernelTime, &userTime)) {
                        ULONGLONG createTime64 = ((ULONGLONG)createTime.dwHighDateTime << 32) |
                            createTime.dwLowDateTime;

                        // �ҵ�����ʱ��������̣߳�ͨ�������̣߳�
                        if (createTime64 < minCreateTime) {
                            minCreateTime = createTime64;
                            mainThreadId = te32.th32ThreadID;
                        }
                    }
                    CloseHandle(hThread);
                }
            }
        } while (Thread32Next(hSnapshot, &te32));
    }

    CloseHandle(hSnapshot);
    return mainThreadId;
}

// ���ҽ��̵������߳�ID
DWORD FindAnyThreadId(DWORD processId)
{
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }

    THREADENTRY32 te32;
    te32.dwSize = sizeof(THREADENTRY32);

    if (Thread32First(hSnapshot, &te32)) {
        do {
            if (te32.th32OwnerProcessID == processId) {
                DWORD threadId = te32.th32ThreadID;
                CloseHandle(hSnapshot);
                return threadId;
            }
        } while (Thread32Next(hSnapshot, &te32));
    }

    CloseHandle(hSnapshot);
    return 0;
}

// ��ȡԶ�̽����е�ģ����
HMODULE GetRemoteModuleHandle(DWORD processId, LPCWSTR moduleName)
{
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, processId);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return NULL;
    }

    MODULEENTRY32W me32;
    me32.dwSize = sizeof(MODULEENTRY32W);

    HMODULE hModule = NULL;

    if (Module32FirstW(hSnapshot, &me32)) {
        do {
            // ��ȡģ���ļ���������·����
            WCHAR moduleFile[MAX_PATH];
            const WCHAR* lastBackslash = wcsrchr(moduleName, L'\\');
            const WCHAR* lastSlash = wcsrchr(moduleName, L'/');
            const WCHAR* fileName = NULL;

            if (lastBackslash || lastSlash) {
                fileName = (lastBackslash > lastSlash) ? lastBackslash + 1 : lastSlash + 1;
            }
            else {
                fileName = (WCHAR*)moduleName;
            }

            // �Ƚ�ģ�����������ִ�Сд��
            if (_wcsicmp(me32.szModule, fileName) == 0) {
                hModule = me32.hModule;
                break;
            }
        } while (Module32NextW(hSnapshot, &me32));
    }

    CloseHandle(hSnapshot);
    return hModule;
}

// �������Ƿ�������
BOOL IsProcessRunning(DWORD processId)
{
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, processId);
    if (hProcess) {
        DWORD exitCode = 0;
        if (GetExitCodeProcess(hProcess, &exitCode)) {
            CloseHandle(hProcess);
            return (exitCode == STILL_ACTIVE);
        }
        CloseHandle(hProcess);
    }
    return FALSE;
}

// ���ݽ�������ȡ����ID
DWORD GetProcessIdByName(LPCWSTR processName)
{
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }

    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32W);

    DWORD processId = 0;

    if (Process32FirstW(hSnapshot, &pe32)) {
        do {
            if (_wcsicmp(pe32.szExeFile, processName) == 0) {
                processId = pe32.th32ProcessID;
                break;
            }
        } while (Process32NextW(hSnapshot, &pe32));
    }

    CloseHandle(hSnapshot);
    return processId;
}