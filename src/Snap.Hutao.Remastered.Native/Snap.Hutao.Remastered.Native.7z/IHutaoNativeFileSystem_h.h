

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeFileSystem.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeFileSystem_h_h__
#define __IHutaoNativeFileSystem_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeFileSystem_FWD_DEFINED__
#define __IHutaoNativeFileSystem_FWD_DEFINED__
typedef interface IHutaoNativeFileSystem IHutaoNativeFileSystem;

#endif 	/* __IHutaoNativeFileSystem_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"
#include "types.h"
#include "IHutaoString.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeFileSystem_INTERFACE_DEFINED__
#define __IHutaoNativeFileSystem_INTERFACE_DEFINED__

/* interface IHutaoNativeFileSystem */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeFileSystem;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FDD58117-0C7F-44D8-A7A2-8B1766474A93")
    IHutaoNativeFileSystem : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE RenameItem( 
            /* [in] */ PCWSTR filePath,
            /* [in] */ PCWSTR newName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RenameItemWithOptions( 
            /* [in] */ PCWSTR filePath,
            /* [in] */ PCWSTR newName,
            /* [in] */ long flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveItem( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveItemWithOptions( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ long flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveItemWithName( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveItemWithNameAndOptions( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name,
            /* [in] */ long flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CopyItem( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CopyItemWithOptions( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ long flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CopyItemWithName( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CopyItemWithNameAndOptions( 
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name,
            /* [in] */ long flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteItem( 
            /* [in] */ PCWSTR filePath) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteItemWithOptions( 
            /* [in] */ PCWSTR filePath,
            /* [in] */ long flags) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeFileSystemVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeFileSystem * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeFileSystem * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeFileSystem * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeFileSystem * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeFileSystem * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, RenameItem)
        HRESULT ( STDMETHODCALLTYPE *RenameItem )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR filePath,
            /* [in] */ PCWSTR newName);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, RenameItemWithOptions)
        HRESULT ( STDMETHODCALLTYPE *RenameItemWithOptions )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR filePath,
            /* [in] */ PCWSTR newName,
            /* [in] */ long flags);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, MoveItem)
        HRESULT ( STDMETHODCALLTYPE *MoveItem )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, MoveItemWithOptions)
        HRESULT ( STDMETHODCALLTYPE *MoveItemWithOptions )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ long flags);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, MoveItemWithName)
        HRESULT ( STDMETHODCALLTYPE *MoveItemWithName )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, MoveItemWithNameAndOptions)
        HRESULT ( STDMETHODCALLTYPE *MoveItemWithNameAndOptions )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name,
            /* [in] */ long flags);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, CopyItem)
        HRESULT ( STDMETHODCALLTYPE *CopyItem )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, CopyItemWithOptions)
        HRESULT ( STDMETHODCALLTYPE *CopyItemWithOptions )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ long flags);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, CopyItemWithName)
        HRESULT ( STDMETHODCALLTYPE *CopyItemWithName )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, CopyItemWithNameAndOptions)
        HRESULT ( STDMETHODCALLTYPE *CopyItemWithNameAndOptions )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR oldPath,
            /* [in] */ PCWSTR newFolder,
            /* [in] */ PCWSTR name,
            /* [in] */ long flags);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, DeleteItem)
        HRESULT ( STDMETHODCALLTYPE *DeleteItem )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR filePath);
        
        DECLSPEC_XFGVIRT(IHutaoNativeFileSystem, DeleteItemWithOptions)
        HRESULT ( STDMETHODCALLTYPE *DeleteItemWithOptions )( 
            IHutaoNativeFileSystem * This,
            /* [in] */ PCWSTR filePath,
            /* [in] */ long flags);
        
        END_INTERFACE
    } IHutaoNativeFileSystemVtbl;

    interface IHutaoNativeFileSystem
    {
        CONST_VTBL struct IHutaoNativeFileSystemVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeFileSystem_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeFileSystem_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeFileSystem_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeFileSystem_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeFileSystem_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeFileSystem_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeFileSystem_RenameItem(This,filePath,newName)	\
    ( (This)->lpVtbl -> RenameItem(This,filePath,newName) ) 

#define IHutaoNativeFileSystem_RenameItemWithOptions(This,filePath,newName,flags)	\
    ( (This)->lpVtbl -> RenameItemWithOptions(This,filePath,newName,flags) ) 

#define IHutaoNativeFileSystem_MoveItem(This,oldPath,newFolder)	\
    ( (This)->lpVtbl -> MoveItem(This,oldPath,newFolder) ) 

#define IHutaoNativeFileSystem_MoveItemWithOptions(This,oldPath,newFolder,flags)	\
    ( (This)->lpVtbl -> MoveItemWithOptions(This,oldPath,newFolder,flags) ) 

#define IHutaoNativeFileSystem_MoveItemWithName(This,oldPath,newFolder,name)	\
    ( (This)->lpVtbl -> MoveItemWithName(This,oldPath,newFolder,name) ) 

#define IHutaoNativeFileSystem_MoveItemWithNameAndOptions(This,oldPath,newFolder,name,flags)	\
    ( (This)->lpVtbl -> MoveItemWithNameAndOptions(This,oldPath,newFolder,name,flags) ) 

#define IHutaoNativeFileSystem_CopyItem(This,oldPath,newFolder)	\
    ( (This)->lpVtbl -> CopyItem(This,oldPath,newFolder) ) 

#define IHutaoNativeFileSystem_CopyItemWithOptions(This,oldPath,newFolder,flags)	\
    ( (This)->lpVtbl -> CopyItemWithOptions(This,oldPath,newFolder,flags) ) 

#define IHutaoNativeFileSystem_CopyItemWithName(This,oldPath,newFolder,name)	\
    ( (This)->lpVtbl -> CopyItemWithName(This,oldPath,newFolder,name) ) 

#define IHutaoNativeFileSystem_CopyItemWithNameAndOptions(This,oldPath,newFolder,name,flags)	\
    ( (This)->lpVtbl -> CopyItemWithNameAndOptions(This,oldPath,newFolder,name,flags) ) 

#define IHutaoNativeFileSystem_DeleteItem(This,filePath)	\
    ( (This)->lpVtbl -> DeleteItem(This,filePath) ) 

#define IHutaoNativeFileSystem_DeleteItemWithOptions(This,filePath,flags)	\
    ( (This)->lpVtbl -> DeleteItemWithOptions(This,filePath,flags) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeFileSystem_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


