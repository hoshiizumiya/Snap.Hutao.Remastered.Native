#pragma once

#include "IHutaoNativeDeviceCapabilities_h.h"