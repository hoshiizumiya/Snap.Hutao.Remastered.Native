

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeWindowSubclass.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeWindowSubclass_h_h__
#define __IHutaoNativeWindowSubclass_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeWindowSubclass_FWD_DEFINED__
#define __IHutaoNativeWindowSubclass_FWD_DEFINED__
typedef interface IHutaoNativeWindowSubclass IHutaoNativeWindowSubclass;

#endif 	/* __IHutaoNativeWindowSubclass_FWD_DEFINED__ */


#ifndef __IHutaoNativeWindowSubclass2_FWD_DEFINED__
#define __IHutaoNativeWindowSubclass2_FWD_DEFINED__
typedef interface IHutaoNativeWindowSubclass2 IHutaoNativeWindowSubclass2;

#endif 	/* __IHutaoNativeWindowSubclass2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeWindowSubclass_INTERFACE_DEFINED__
#define __IHutaoNativeWindowSubclass_INTERFACE_DEFINED__

/* interface IHutaoNativeWindowSubclass */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeWindowSubclass;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9631921E-A6CA-4150-9939-99B5467B2FD6")
    IHutaoNativeWindowSubclass : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Attach( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Detach( void) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeWindowSubclassVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeWindowSubclass * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeWindowSubclass * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeWindowSubclass * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeWindowSubclass * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeWindowSubclass * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeWindowSubclass * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeWindowSubclass, Attach)
        HRESULT ( STDMETHODCALLTYPE *Attach )( 
            IHutaoNativeWindowSubclass * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeWindowSubclass, Detach)
        HRESULT ( STDMETHODCALLTYPE *Detach )( 
            IHutaoNativeWindowSubclass * This);
        
        END_INTERFACE
    } IHutaoNativeWindowSubclassVtbl;

    interface IHutaoNativeWindowSubclass
    {
        CONST_VTBL struct IHutaoNativeWindowSubclassVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeWindowSubclass_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeWindowSubclass_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeWindowSubclass_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeWindowSubclass_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeWindowSubclass_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeWindowSubclass_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeWindowSubclass_Attach(This)	\
    ( (This)->lpVtbl -> Attach(This) ) 

#define IHutaoNativeWindowSubclass_Detach(This)	\
    ( (This)->lpVtbl -> Detach(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeWindowSubclass_INTERFACE_DEFINED__ */


#ifndef __IHutaoNativeWindowSubclass2_INTERFACE_DEFINED__
#define __IHutaoNativeWindowSubclass2_INTERFACE_DEFINED__

/* interface IHutaoNativeWindowSubclass2 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeWindowSubclass2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D3D8B1C9-C83D-472B-AE9C-B65618B0F3AE")
    IHutaoNativeWindowSubclass2 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE InitializeTaskbarProgress( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTaskbarProgress( 
            /* [in] */ UINT32 flags,
            /* [in] */ ULONGLONG value,
            /* [in] */ ULONGLONG maximum) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeWindowSubclass2Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeWindowSubclass2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeWindowSubclass2 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeWindowSubclass2 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeWindowSubclass2 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeWindowSubclass2 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeWindowSubclass2 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeWindowSubclass2, InitializeTaskbarProgress)
        HRESULT ( STDMETHODCALLTYPE *InitializeTaskbarProgress )( 
            IHutaoNativeWindowSubclass2 * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeWindowSubclass2, SetTaskbarProgress)
        HRESULT ( STDMETHODCALLTYPE *SetTaskbarProgress )( 
            IHutaoNativeWindowSubclass2 * This,
            /* [in] */ UINT32 flags,
            /* [in] */ ULONGLONG value,
            /* [in] */ ULONGLONG maximum);
        
        END_INTERFACE
    } IHutaoNativeWindowSubclass2Vtbl;

    interface IHutaoNativeWindowSubclass2
    {
        CONST_VTBL struct IHutaoNativeWindowSubclass2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeWindowSubclass2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeWindowSubclass2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeWindowSubclass2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeWindowSubclass2_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeWindowSubclass2_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeWindowSubclass2_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeWindowSubclass2_InitializeTaskbarProgress(This)	\
    ( (This)->lpVtbl -> InitializeTaskbarProgress(This) ) 

#define IHutaoNativeWindowSubclass2_SetTaskbarProgress(This,flags,value,maximum)	\
    ( (This)->lpVtbl -> SetTaskbarProgress(This,flags,value,maximum) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeWindowSubclass2_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


