#pragma once

#include "Types_h.h"

typedef unsigned char byte;
typedef unsigned int WIN32_ERROR;
typedef void* nint;
typedef unsigned long uint;

typedef nint GCHandle;

#define E_NOT_FOUND 0x80070490
