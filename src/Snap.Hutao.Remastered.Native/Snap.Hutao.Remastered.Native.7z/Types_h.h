

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for Types.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */


#ifndef __Types_h_h__
#define __Types_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_Types_0000_0000 */
/* [local] */ 

typedef long long nint;

typedef unsigned long uint;

typedef /* [string] */ const wchar_t *LPCWSTR;

typedef LPCWSTR PCWSTR;

typedef INT64 HANDLE;

typedef INT64 HWND;

typedef struct HutaoPrivateWindowsVersion
    {
    UINT major;
    UINT minor;
    UINT build;
    UINT revision;
    } 	HutaoPrivateWindowsVersion;

typedef 
enum HutaoNativeHotKeyActionKind
    {
        None	= 0,
        MouseClickRepeatForever	= 1,
        KeyPressRepeatForever	= 2
    } 	HutaoNativeHotKeyActionKind;

typedef 
enum HOT_KEY_MODIFIERS
    {
        MOD_ALT	= 1,
        MOD_CONTROL	= 2,
        MOD_NOREPEAT	= 0x4000,
        MOD_SHIFT	= 4,
        MOD_WIN	= 8
    } 	HOT_KEY_MODIFIERS;

typedef struct HutaoNativeProcessStartInfo
    {
    PCWSTR ApplicationName;
    PCWSTR CommandLine;
    BOOL InheritHandles;
    long CreationFlags;
    PCWSTR CurrentDirectory;
    } 	HutaoNativeProcessStartInfo;



extern RPC_IF_HANDLE __MIDL_itf_Types_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_Types_0000_0000_v0_0_s_ifspec;

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


