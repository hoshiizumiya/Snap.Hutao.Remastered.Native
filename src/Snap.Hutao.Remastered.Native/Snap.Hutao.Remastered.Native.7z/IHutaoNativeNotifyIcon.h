#pragma once

#include "IHutaoNativeNotifyIcon_h.h"