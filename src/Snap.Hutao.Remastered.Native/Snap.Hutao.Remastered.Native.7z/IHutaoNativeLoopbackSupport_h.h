

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeLoopbackSupport.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeLoopbackSupport_h_h__
#define __IHutaoNativeLoopbackSupport_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeLoopbackSupport_FWD_DEFINED__
#define __IHutaoNativeLoopbackSupport_FWD_DEFINED__
typedef interface IHutaoNativeLoopbackSupport IHutaoNativeLoopbackSupport;

#endif 	/* __IHutaoNativeLoopbackSupport_FWD_DEFINED__ */


#ifndef __IHutaoNativeLoopbackSupport2_FWD_DEFINED__
#define __IHutaoNativeLoopbackSupport2_FWD_DEFINED__
typedef interface IHutaoNativeLoopbackSupport2 IHutaoNativeLoopbackSupport2;

#endif 	/* __IHutaoNativeLoopbackSupport2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"
#include "IHutaoString.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeLoopbackSupport_INTERFACE_DEFINED__
#define __IHutaoNativeLoopbackSupport_INTERFACE_DEFINED__

/* interface IHutaoNativeLoopbackSupport */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeLoopbackSupport;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8607ACE4-313C-4C26-B1FB-CA11173B6953")
    IHutaoNativeLoopbackSupport : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE IsEnabled( 
            /* [in] */ HSTRING familyName,
            /* [in] */ IHutaoString *sid,
            /* [retval][out] */ boolean *enabled) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Enable( 
            /* [in] */ HSTRING familyName,
            /* [in] */ IHutaoString *sid) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeLoopbackSupportVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeLoopbackSupport * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeLoopbackSupport * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeLoopbackSupport * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeLoopbackSupport * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeLoopbackSupport * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeLoopbackSupport * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeLoopbackSupport, IsEnabled)
        HRESULT ( STDMETHODCALLTYPE *IsEnabled )( 
            IHutaoNativeLoopbackSupport * This,
            /* [in] */ HSTRING familyName,
            /* [in] */ IHutaoString *sid,
            /* [retval][out] */ boolean *enabled);
        
        DECLSPEC_XFGVIRT(IHutaoNativeLoopbackSupport, Enable)
        HRESULT ( STDMETHODCALLTYPE *Enable )( 
            IHutaoNativeLoopbackSupport * This,
            /* [in] */ HSTRING familyName,
            /* [in] */ IHutaoString *sid);
        
        END_INTERFACE
    } IHutaoNativeLoopbackSupportVtbl;

    interface IHutaoNativeLoopbackSupport
    {
        CONST_VTBL struct IHutaoNativeLoopbackSupportVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeLoopbackSupport_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeLoopbackSupport_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeLoopbackSupport_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeLoopbackSupport_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeLoopbackSupport_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeLoopbackSupport_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeLoopbackSupport_IsEnabled(This,familyName,sid,enabled)	\
    ( (This)->lpVtbl -> IsEnabled(This,familyName,sid,enabled) ) 

#define IHutaoNativeLoopbackSupport_Enable(This,familyName,sid)	\
    ( (This)->lpVtbl -> Enable(This,familyName,sid) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeLoopbackSupport_INTERFACE_DEFINED__ */


#ifndef __IHutaoNativeLoopbackSupport2_INTERFACE_DEFINED__
#define __IHutaoNativeLoopbackSupport2_INTERFACE_DEFINED__

/* interface IHutaoNativeLoopbackSupport2 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeLoopbackSupport2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A5D67980-F495-4F52-BEF0-27D047E20174")
    IHutaoNativeLoopbackSupport2 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE IsPublicFirewallEnabled( 
            /* [retval][out] */ boolean *enabled) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeLoopbackSupport2Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeLoopbackSupport2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeLoopbackSupport2 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeLoopbackSupport2 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeLoopbackSupport2 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeLoopbackSupport2 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeLoopbackSupport2 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeLoopbackSupport2, IsPublicFirewallEnabled)
        HRESULT ( STDMETHODCALLTYPE *IsPublicFirewallEnabled )( 
            IHutaoNativeLoopbackSupport2 * This,
            /* [retval][out] */ boolean *enabled);
        
        END_INTERFACE
    } IHutaoNativeLoopbackSupport2Vtbl;

    interface IHutaoNativeLoopbackSupport2
    {
        CONST_VTBL struct IHutaoNativeLoopbackSupport2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeLoopbackSupport2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeLoopbackSupport2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeLoopbackSupport2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeLoopbackSupport2_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeLoopbackSupport2_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeLoopbackSupport2_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeLoopbackSupport2_IsPublicFirewallEnabled(This,enabled)	\
    ( (This)->lpVtbl -> IsPublicFirewallEnabled(This,enabled) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeLoopbackSupport2_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  HSTRING_UserSize(     unsigned long *, unsigned long            , HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserMarshal(  unsigned long *, unsigned char *, HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserUnmarshal(unsigned long *, unsigned char *, HSTRING * ); 
void                      __RPC_USER  HSTRING_UserFree(     unsigned long *, HSTRING * ); 

unsigned long             __RPC_USER  HSTRING_UserSize64(     unsigned long *, unsigned long            , HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserMarshal64(  unsigned long *, unsigned char *, HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserUnmarshal64(unsigned long *, unsigned char *, HSTRING * ); 
void                      __RPC_USER  HSTRING_UserFree64(     unsigned long *, HSTRING * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


