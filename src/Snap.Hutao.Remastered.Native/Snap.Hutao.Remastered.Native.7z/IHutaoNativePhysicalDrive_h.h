

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativePhysicalDrive.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativePhysicalDrive_h_h__
#define __IHutaoNativePhysicalDrive_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativePhysicalDrive_FWD_DEFINED__
#define __IHutaoNativePhysicalDrive_FWD_DEFINED__
typedef interface IHutaoNativePhysicalDrive IHutaoNativePhysicalDrive;

#endif 	/* __IHutaoNativePhysicalDrive_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"
#include "Types.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativePhysicalDrive_INTERFACE_DEFINED__
#define __IHutaoNativePhysicalDrive_INTERFACE_DEFINED__

/* interface IHutaoNativePhysicalDrive */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativePhysicalDrive;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F90535D7-AFF6-4008-BA8C-15C47FC9660D")
    IHutaoNativePhysicalDrive : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE IsPathOnSolidStateDrive( 
            /* [in] */ PCWSTR root,
            /* [out] */ BOOL *isSSD) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativePhysicalDriveVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativePhysicalDrive * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativePhysicalDrive * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativePhysicalDrive * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativePhysicalDrive * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativePhysicalDrive * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativePhysicalDrive * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativePhysicalDrive, IsPathOnSolidStateDrive)
        HRESULT ( STDMETHODCALLTYPE *IsPathOnSolidStateDrive )( 
            IHutaoNativePhysicalDrive * This,
            /* [in] */ PCWSTR root,
            /* [out] */ BOOL *isSSD);
        
        END_INTERFACE
    } IHutaoNativePhysicalDriveVtbl;

    interface IHutaoNativePhysicalDrive
    {
        CONST_VTBL struct IHutaoNativePhysicalDriveVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativePhysicalDrive_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativePhysicalDrive_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativePhysicalDrive_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativePhysicalDrive_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativePhysicalDrive_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativePhysicalDrive_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativePhysicalDrive_IsPathOnSolidStateDrive(This,root,isSSD)	\
    ( (This)->lpVtbl -> IsPathOnSolidStateDrive(This,root,isSSD) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativePhysicalDrive_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


