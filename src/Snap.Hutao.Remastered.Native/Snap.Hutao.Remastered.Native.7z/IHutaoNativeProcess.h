#pragma once

#include "IHutaoNativeProcess_h.h"
