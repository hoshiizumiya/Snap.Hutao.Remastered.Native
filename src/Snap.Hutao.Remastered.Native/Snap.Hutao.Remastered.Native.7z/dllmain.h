#pragma once

#define DLL_EXPORT extern "C" __declspec(dllexport)