

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeDeviceCapabilities.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeDeviceCapabilities_h_h__
#define __IHutaoNativeDeviceCapabilities_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeDeviceCapabilities_FWD_DEFINED__
#define __IHutaoNativeDeviceCapabilities_FWD_DEFINED__
typedef interface IHutaoNativeDeviceCapabilities IHutaoNativeDeviceCapabilities;

#endif 	/* __IHutaoNativeDeviceCapabilities_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeDeviceCapabilities_INTERFACE_DEFINED__
#define __IHutaoNativeDeviceCapabilities_INTERFACE_DEFINED__

/* interface IHutaoNativeDeviceCapabilities */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeDeviceCapabilities;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1920EFA1-9953-4260-AFB1-35B1672758C1")
    IHutaoNativeDeviceCapabilities : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetPrimaryScreenVerticalRefreshRate( 
            /* [out] */ int *refreshRate) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeDeviceCapabilitiesVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeDeviceCapabilities * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeDeviceCapabilities * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeDeviceCapabilities * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeDeviceCapabilities * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeDeviceCapabilities * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeDeviceCapabilities * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeDeviceCapabilities, GetPrimaryScreenVerticalRefreshRate)
        HRESULT ( STDMETHODCALLTYPE *GetPrimaryScreenVerticalRefreshRate )( 
            IHutaoNativeDeviceCapabilities * This,
            /* [out] */ int *refreshRate);
        
        END_INTERFACE
    } IHutaoNativeDeviceCapabilitiesVtbl;

    interface IHutaoNativeDeviceCapabilities
    {
        CONST_VTBL struct IHutaoNativeDeviceCapabilitiesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeDeviceCapabilities_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeDeviceCapabilities_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeDeviceCapabilities_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeDeviceCapabilities_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeDeviceCapabilities_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeDeviceCapabilities_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeDeviceCapabilities_GetPrimaryScreenVerticalRefreshRate(This,refreshRate)	\
    ( (This)->lpVtbl -> GetPrimaryScreenVerticalRefreshRate(This,refreshRate) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeDeviceCapabilities_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


