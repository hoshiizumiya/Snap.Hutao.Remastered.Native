

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNative.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNative_h_h__
#define __IHutaoNative_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativePrivate_FWD_DEFINED__
#define __IHutaoNativePrivate_FWD_DEFINED__
typedef interface IHutaoNativePrivate IHutaoNativePrivate;

#endif 	/* __IHutaoNativePrivate_FWD_DEFINED__ */


#ifndef __IHutaoPrivate2_FWD_DEFINED__
#define __IHutaoPrivate2_FWD_DEFINED__
typedef interface IHutaoPrivate2 IHutaoPrivate2;

#endif 	/* __IHutaoPrivate2_FWD_DEFINED__ */


#ifndef __IHutaoNative_FWD_DEFINED__
#define __IHutaoNative_FWD_DEFINED__
typedef interface IHutaoNative IHutaoNative;

#endif 	/* __IHutaoNative_FWD_DEFINED__ */


#ifndef __IHutaoNative2_FWD_DEFINED__
#define __IHutaoNative2_FWD_DEFINED__
typedef interface IHutaoNative2 IHutaoNative2;

#endif 	/* __IHutaoNative2_FWD_DEFINED__ */


#ifndef __IHutaoNative3_FWD_DEFINED__
#define __IHutaoNative3_FWD_DEFINED__
typedef interface IHutaoNative3 IHutaoNative3;

#endif 	/* __IHutaoNative3_FWD_DEFINED__ */


#ifndef __IHutaoNative4_FWD_DEFINED__
#define __IHutaoNative4_FWD_DEFINED__
typedef interface IHutaoNative4 IHutaoNative4;

#endif 	/* __IHutaoNative4_FWD_DEFINED__ */


#ifndef __IHutaoNative5_FWD_DEFINED__
#define __IHutaoNative5_FWD_DEFINED__
typedef interface IHutaoNative5 IHutaoNative5;

#endif 	/* __IHutaoNative5_FWD_DEFINED__ */


#ifndef __IHutaoNative6_FWD_DEFINED__
#define __IHutaoNative6_FWD_DEFINED__
typedef interface IHutaoNative6 IHutaoNative6;

#endif 	/* __IHutaoNative6_FWD_DEFINED__ */


#ifndef __IHutaoNative7_FWD_DEFINED__
#define __IHutaoNative7_FWD_DEFINED__
typedef interface IHutaoNative7 IHutaoNative7;

#endif 	/* __IHutaoNative7_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"
#include "types.h"
#include "IHutaoString.h"
#include "IHutaoNativeLoopbackSupport.h"
#include "IHutaoNativeRegistryNotification.h"
#include "IHutaoNativeWindowSubclass.h"
#include "IHutaoNativeWindowNonRude.h"
#include "IHutaoNativeDeviceCapabilities.h"
#include "IHutaoNativePhysicalDrive.h"
#include "IHutaoNativeLogicalDrive.h"
#include "IHutaoNativeInputLowLevelKeyboardSource.h"
#include "IHutaoNativeFileSystem.h"
#include "IHutaoNativeNotifyIcon.h"
#include "IHutaoNativeHotKeyAction.h"
#include "IHutaoNativeProcess.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativePrivate_INTERFACE_DEFINED__
#define __IHutaoNativePrivate_INTERFACE_DEFINED__

/* interface IHutaoNativePrivate */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativePrivate;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1A6980D9-EB36-4E3E-86E7-3665C57C6E8D")
    IHutaoNativePrivate : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE IsCurrentWindowsVersionSupported( 
            /* [out] */ BOOL *isSupported) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetWindowsVersion( 
            /* [out] */ HutaoPrivateWindowsVersion *pv) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowErrorMessage( 
            /* [in] */ PCWSTR title,
            /* [in] */ PCWSTR message) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativePrivateVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativePrivate * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativePrivate * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativePrivate * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativePrivate * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativePrivate * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativePrivate * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativePrivate, IsCurrentWindowsVersionSupported)
        HRESULT ( STDMETHODCALLTYPE *IsCurrentWindowsVersionSupported )( 
            IHutaoNativePrivate * This,
            /* [out] */ BOOL *isSupported);
        
        DECLSPEC_XFGVIRT(IHutaoNativePrivate, GetWindowsVersion)
        HRESULT ( STDMETHODCALLTYPE *GetWindowsVersion )( 
            IHutaoNativePrivate * This,
            /* [out] */ HutaoPrivateWindowsVersion *pv);
        
        DECLSPEC_XFGVIRT(IHutaoNativePrivate, ShowErrorMessage)
        HRESULT ( STDMETHODCALLTYPE *ShowErrorMessage )( 
            IHutaoNativePrivate * This,
            /* [in] */ PCWSTR title,
            /* [in] */ PCWSTR message);
        
        END_INTERFACE
    } IHutaoNativePrivateVtbl;

    interface IHutaoNativePrivate
    {
        CONST_VTBL struct IHutaoNativePrivateVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativePrivate_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativePrivate_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativePrivate_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativePrivate_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativePrivate_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativePrivate_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativePrivate_IsCurrentWindowsVersionSupported(This,isSupported)	\
    ( (This)->lpVtbl -> IsCurrentWindowsVersionSupported(This,isSupported) ) 

#define IHutaoNativePrivate_GetWindowsVersion(This,pv)	\
    ( (This)->lpVtbl -> GetWindowsVersion(This,pv) ) 

#define IHutaoNativePrivate_ShowErrorMessage(This,title,message)	\
    ( (This)->lpVtbl -> ShowErrorMessage(This,title,message) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativePrivate_INTERFACE_DEFINED__ */


#ifndef __IHutaoPrivate2_INTERFACE_DEFINED__
#define __IHutaoPrivate2_INTERFACE_DEFINED__

/* interface IHutaoPrivate2 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoPrivate2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4E5D37CF-5F38-4FF2-9059-DF39CA696365")
    IHutaoPrivate2 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ExchangeGameUidForIdentifier1820( 
            /* [in] */ PCWSTR gameUid,
            /* [out] */ byte *identifier) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoPrivate2Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoPrivate2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoPrivate2 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoPrivate2 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoPrivate2 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoPrivate2 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoPrivate2 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoPrivate2, ExchangeGameUidForIdentifier1820)
        HRESULT ( STDMETHODCALLTYPE *ExchangeGameUidForIdentifier1820 )( 
            IHutaoPrivate2 * This,
            /* [in] */ PCWSTR gameUid,
            /* [out] */ byte *identifier);
        
        END_INTERFACE
    } IHutaoPrivate2Vtbl;

    interface IHutaoPrivate2
    {
        CONST_VTBL struct IHutaoPrivate2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoPrivate2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoPrivate2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoPrivate2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoPrivate2_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoPrivate2_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoPrivate2_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoPrivate2_ExchangeGameUidForIdentifier1820(This,gameUid,identifier)	\
    ( (This)->lpVtbl -> ExchangeGameUidForIdentifier1820(This,gameUid,identifier) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoPrivate2_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative_INTERFACE_DEFINED__
#define __IHutaoNative_INTERFACE_DEFINED__

/* interface IHutaoNative */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D00F73FF-A1C7-4091-8CB6-D90991DD40CB")
    IHutaoNative : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeLoopbackSupport( 
            /* [out] */ IHutaoNativeLoopbackSupport **ppv) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MakeRegistryNotification( 
            /* [in] */ HSTRING keyPath,
            /* [out] */ IHutaoNativeRegistryNotification **ppv) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MakeWindowSubclass( 
            /* [in] */ INT64 hWnd,
            /* [in] */ nint callback,
            /* [in] */ INT64 userData,
            /* [out] */ IHutaoNativeWindowSubclass **ppv) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MakeWindowNonRude( 
            /* [in] */ INT64 hWnd,
            /* [out] */ IHutaoNativeWindowNonRude **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative, MakeLoopbackSupport)
        HRESULT ( STDMETHODCALLTYPE *MakeLoopbackSupport )( 
            IHutaoNative * This,
            /* [out] */ IHutaoNativeLoopbackSupport **ppv);
        
        DECLSPEC_XFGVIRT(IHutaoNative, MakeRegistryNotification)
        HRESULT ( STDMETHODCALLTYPE *MakeRegistryNotification )( 
            IHutaoNative * This,
            /* [in] */ HSTRING keyPath,
            /* [out] */ IHutaoNativeRegistryNotification **ppv);
        
        DECLSPEC_XFGVIRT(IHutaoNative, MakeWindowSubclass)
        HRESULT ( STDMETHODCALLTYPE *MakeWindowSubclass )( 
            IHutaoNative * This,
            /* [in] */ INT64 hWnd,
            /* [in] */ nint callback,
            /* [in] */ INT64 userData,
            /* [out] */ IHutaoNativeWindowSubclass **ppv);
        
        DECLSPEC_XFGVIRT(IHutaoNative, MakeWindowNonRude)
        HRESULT ( STDMETHODCALLTYPE *MakeWindowNonRude )( 
            IHutaoNative * This,
            /* [in] */ INT64 hWnd,
            /* [out] */ IHutaoNativeWindowNonRude **ppv);
        
        END_INTERFACE
    } IHutaoNativeVtbl;

    interface IHutaoNative
    {
        CONST_VTBL struct IHutaoNativeVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative_MakeLoopbackSupport(This,ppv)	\
    ( (This)->lpVtbl -> MakeLoopbackSupport(This,ppv) ) 

#define IHutaoNative_MakeRegistryNotification(This,keyPath,ppv)	\
    ( (This)->lpVtbl -> MakeRegistryNotification(This,keyPath,ppv) ) 

#define IHutaoNative_MakeWindowSubclass(This,hWnd,callback,userData,ppv)	\
    ( (This)->lpVtbl -> MakeWindowSubclass(This,hWnd,callback,userData,ppv) ) 

#define IHutaoNative_MakeWindowNonRude(This,hWnd,ppv)	\
    ( (This)->lpVtbl -> MakeWindowNonRude(This,hWnd,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative2_INTERFACE_DEFINED__
#define __IHutaoNative2_INTERFACE_DEFINED__

/* interface IHutaoNative2 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("338487EE-9592-4171-89DD-1E6B9EDB2C8E")
    IHutaoNative2 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeDeviceCapabilities( 
            /* [out] */ IHutaoNativeDeviceCapabilities **ppv) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MakePhysicalDrive( 
            /* [out] */ IHutaoNativePhysicalDrive **ppv) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MakeLogicalDrive( 
            /* [out] */ IHutaoNativeLogicalDrive **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNative2Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative2 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative2 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative2 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative2 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative2 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative2, MakeDeviceCapabilities)
        HRESULT ( STDMETHODCALLTYPE *MakeDeviceCapabilities )( 
            IHutaoNative2 * This,
            /* [out] */ IHutaoNativeDeviceCapabilities **ppv);
        
        DECLSPEC_XFGVIRT(IHutaoNative2, MakePhysicalDrive)
        HRESULT ( STDMETHODCALLTYPE *MakePhysicalDrive )( 
            IHutaoNative2 * This,
            /* [out] */ IHutaoNativePhysicalDrive **ppv);
        
        DECLSPEC_XFGVIRT(IHutaoNative2, MakeLogicalDrive)
        HRESULT ( STDMETHODCALLTYPE *MakeLogicalDrive )( 
            IHutaoNative2 * This,
            /* [out] */ IHutaoNativeLogicalDrive **ppv);
        
        END_INTERFACE
    } IHutaoNative2Vtbl;

    interface IHutaoNative2
    {
        CONST_VTBL struct IHutaoNative2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative2_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative2_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative2_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative2_MakeDeviceCapabilities(This,ppv)	\
    ( (This)->lpVtbl -> MakeDeviceCapabilities(This,ppv) ) 

#define IHutaoNative2_MakePhysicalDrive(This,ppv)	\
    ( (This)->lpVtbl -> MakePhysicalDrive(This,ppv) ) 

#define IHutaoNative2_MakeLogicalDrive(This,ppv)	\
    ( (This)->lpVtbl -> MakeLogicalDrive(This,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative2_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative3_INTERFACE_DEFINED__
#define __IHutaoNative3_INTERFACE_DEFINED__

/* interface IHutaoNative3 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative3;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("135FACE1-3184-4D12-B4D0-21FFB6A88D25")
    IHutaoNative3 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeInputLowLevelKeyboardSource( 
            /* [out] */ IHutaoNativeInputLowLevelKeyboardSource **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNative3Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative3 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative3 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative3 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative3 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative3 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative3 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative3, MakeInputLowLevelKeyboardSource)
        HRESULT ( STDMETHODCALLTYPE *MakeInputLowLevelKeyboardSource )( 
            IHutaoNative3 * This,
            /* [out] */ IHutaoNativeInputLowLevelKeyboardSource **ppv);
        
        END_INTERFACE
    } IHutaoNative3Vtbl;

    interface IHutaoNative3
    {
        CONST_VTBL struct IHutaoNative3Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative3_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative3_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative3_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative3_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative3_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative3_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative3_MakeInputLowLevelKeyboardSource(This,ppv)	\
    ( (This)->lpVtbl -> MakeInputLowLevelKeyboardSource(This,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative3_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative4_INTERFACE_DEFINED__
#define __IHutaoNative4_INTERFACE_DEFINED__

/* interface IHutaoNative4 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative4;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("27942FBE-322F-4157-9B8C-A38FDB827B05")
    IHutaoNative4 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeFileSystem( 
            /* [out] */ IHutaoNativeFileSystem **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNative4Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative4 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative4 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative4 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative4 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative4 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative4 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative4, MakeFileSystem)
        HRESULT ( STDMETHODCALLTYPE *MakeFileSystem )( 
            IHutaoNative4 * This,
            /* [out] */ IHutaoNativeFileSystem **ppv);
        
        END_INTERFACE
    } IHutaoNative4Vtbl;

    interface IHutaoNative4
    {
        CONST_VTBL struct IHutaoNative4Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative4_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative4_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative4_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative4_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative4_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative4_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative4_MakeFileSystem(This,ppv)	\
    ( (This)->lpVtbl -> MakeFileSystem(This,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative4_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative5_INTERFACE_DEFINED__
#define __IHutaoNative5_INTERFACE_DEFINED__

/* interface IHutaoNative5 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative5;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7B4D20F1-4DAD-492E-8485-B4701A2ED19B")
    IHutaoNative5 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeNotifyIcon( 
            /* [in] */ PCWSTR iconPath,
            /* [in] */ GUID *id,
            /* [out] */ IHutaoNativeNotifyIcon **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNative5Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative5 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative5 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative5 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative5 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative5 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative5 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative5, MakeNotifyIcon)
        HRESULT ( STDMETHODCALLTYPE *MakeNotifyIcon )( 
            IHutaoNative5 * This,
            /* [in] */ PCWSTR iconPath,
            /* [in] */ GUID *id,
            /* [out] */ IHutaoNativeNotifyIcon **ppv);
        
        END_INTERFACE
    } IHutaoNative5Vtbl;

    interface IHutaoNative5
    {
        CONST_VTBL struct IHutaoNative5Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative5_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative5_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative5_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative5_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative5_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative5_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative5_MakeNotifyIcon(This,iconPath,id,ppv)	\
    ( (This)->lpVtbl -> MakeNotifyIcon(This,iconPath,id,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative5_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative6_INTERFACE_DEFINED__
#define __IHutaoNative6_INTERFACE_DEFINED__

/* interface IHutaoNative6 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative6;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B68CABFA-C55A-49FA-8C51-21615C594E2B")
    IHutaoNative6 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeHotKeyAction( 
            /* [in] */ HutaoNativeHotKeyActionKind kind,
            /* [in] */ nint callback,
            /* [in] */ nint userData,
            /* [out] */ IHutaoNativeHotKeyAction **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNative6Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative6 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative6 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative6 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative6 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative6 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative6 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative6, MakeHotKeyAction)
        HRESULT ( STDMETHODCALLTYPE *MakeHotKeyAction )( 
            IHutaoNative6 * This,
            /* [in] */ HutaoNativeHotKeyActionKind kind,
            /* [in] */ nint callback,
            /* [in] */ nint userData,
            /* [out] */ IHutaoNativeHotKeyAction **ppv);
        
        END_INTERFACE
    } IHutaoNative6Vtbl;

    interface IHutaoNative6
    {
        CONST_VTBL struct IHutaoNative6Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative6_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative6_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative6_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative6_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative6_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative6_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative6_MakeHotKeyAction(This,kind,callback,userData,ppv)	\
    ( (This)->lpVtbl -> MakeHotKeyAction(This,kind,callback,userData,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative6_INTERFACE_DEFINED__ */


#ifndef __IHutaoNative7_INTERFACE_DEFINED__
#define __IHutaoNative7_INTERFACE_DEFINED__

/* interface IHutaoNative7 */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNative7;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B7A49A20-D9E2-43FD-9637-E80190443ABE")
    IHutaoNative7 : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MakeProcess( 
            /* [in] */ HutaoNativeProcessStartInfo info,
            /* [out] */ IHutaoNativeProcess **ppv) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNative7Vtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNative7 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNative7 * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNative7 * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNative7 * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNative7 * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNative7 * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNative7, MakeProcess)
        HRESULT ( STDMETHODCALLTYPE *MakeProcess )( 
            IHutaoNative7 * This,
            /* [in] */ HutaoNativeProcessStartInfo info,
            /* [out] */ IHutaoNativeProcess **ppv);
        
        END_INTERFACE
    } IHutaoNative7Vtbl;

    interface IHutaoNative7
    {
        CONST_VTBL struct IHutaoNative7Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNative7_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNative7_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNative7_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNative7_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNative7_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNative7_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNative7_MakeProcess(This,info,ppv)	\
    ( (This)->lpVtbl -> MakeProcess(This,info,ppv) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNative7_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  HSTRING_UserSize(     unsigned long *, unsigned long            , HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserMarshal(  unsigned long *, unsigned char *, HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserUnmarshal(unsigned long *, unsigned char *, HSTRING * ); 
void                      __RPC_USER  HSTRING_UserFree(     unsigned long *, HSTRING * ); 

unsigned long             __RPC_USER  HSTRING_UserSize64(     unsigned long *, unsigned long            , HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserMarshal64(  unsigned long *, unsigned char *, HSTRING * ); 
unsigned char * __RPC_USER  HSTRING_UserUnmarshal64(unsigned long *, unsigned char *, HSTRING * ); 
void                      __RPC_USER  HSTRING_UserFree64(     unsigned long *, HSTRING * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


