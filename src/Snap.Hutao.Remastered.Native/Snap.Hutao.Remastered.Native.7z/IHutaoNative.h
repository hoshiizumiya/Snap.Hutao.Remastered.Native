#pragma once

#include "IHutaoNativeLoopbackSupport.h"
#include "IHutaoNative_h.h"
#include <Windows.h>
#include <winrt/base.h>

