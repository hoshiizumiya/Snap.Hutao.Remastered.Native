#pragma once

#include "IHutaoString_h.h"
#include <Windows.h>
#include <winrt/base.h>

