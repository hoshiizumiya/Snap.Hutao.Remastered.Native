

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeWindowNonRude.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeWindowNonRude_h_h__
#define __IHutaoNativeWindowNonRude_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeWindowNonRude_FWD_DEFINED__
#define __IHutaoNativeWindowNonRude_FWD_DEFINED__
typedef interface IHutaoNativeWindowNonRude IHutaoNativeWindowNonRude;

#endif 	/* __IHutaoNativeWindowNonRude_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeWindowNonRude_INTERFACE_DEFINED__
#define __IHutaoNativeWindowNonRude_INTERFACE_DEFINED__

/* interface IHutaoNativeWindowNonRude */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeWindowNonRude;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A0AD4485-702B-44B6-B48E-F82240EBBAEF")
    IHutaoNativeWindowNonRude : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Attach( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Detach( void) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeWindowNonRudeVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeWindowNonRude * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeWindowNonRude * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeWindowNonRude * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeWindowNonRude * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeWindowNonRude * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeWindowNonRude * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeWindowNonRude, Attach)
        HRESULT ( STDMETHODCALLTYPE *Attach )( 
            IHutaoNativeWindowNonRude * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeWindowNonRude, Detach)
        HRESULT ( STDMETHODCALLTYPE *Detach )( 
            IHutaoNativeWindowNonRude * This);
        
        END_INTERFACE
    } IHutaoNativeWindowNonRudeVtbl;

    interface IHutaoNativeWindowNonRude
    {
        CONST_VTBL struct IHutaoNativeWindowNonRudeVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeWindowNonRude_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeWindowNonRude_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeWindowNonRude_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeWindowNonRude_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeWindowNonRude_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeWindowNonRude_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeWindowNonRude_Attach(This)	\
    ( (This)->lpVtbl -> Attach(This) ) 

#define IHutaoNativeWindowNonRude_Detach(This)	\
    ( (This)->lpVtbl -> Detach(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeWindowNonRude_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


