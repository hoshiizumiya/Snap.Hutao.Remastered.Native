#pragma once

#include "IHutaoNativeHotKeyAction_h.h"
#include "types.h"
#include <winrt/base.h>
#include <Windows.h>

class HutaoNativeHotKeyAction : public winrt::implements<
    HutaoNativeHotKeyAction,
    IHutaoNativeHotKeyAction,
    winrt::non_agile>
{
public:
    HutaoNativeHotKeyAction();
    ~HutaoNativeHotKeyAction();

    // IHutaoNativeHotKeyAction methods
    virtual HRESULT STDMETHODCALLTYPE Update(HOT_KEY_MODIFIERS modifiers, uint vk) override;
    virtual HRESULT STDMETHODCALLTYPE GetIsEnabled(BOOL* isEnabled) override;
    virtual HRESULT STDMETHODCALLTYPE SetIsEnabled(BOOL isEnabled) override;

private:
    HOT_KEY_MODIFIERS m_modifiers;
    uint m_vk;
    bool m_enabled;
    int m_hotKeyId;
    HWND m_hWnd;
    static UINT s_nextHotKeyId;

    static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
    static ATOM RegisterWindowClass();
    HWND CreateMessageWindow();
    void UnregisterHotKey();
    void RegisterHotKey();
};
