

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeHotKeyAction.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeHotKeyAction_h_h__
#define __IHutaoNativeHotKeyAction_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeHotKeyAction_FWD_DEFINED__
#define __IHutaoNativeHotKeyAction_FWD_DEFINED__
typedef interface IHutaoNativeHotKeyAction IHutaoNativeHotKeyAction;

#endif 	/* __IHutaoNativeHotKeyAction_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "inspectable.h"
#include "Types.h"
#include "IHutaoString.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeHotKeyAction_INTERFACE_DEFINED__
#define __IHutaoNativeHotKeyAction_INTERFACE_DEFINED__

/* interface IHutaoNativeHotKeyAction */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeHotKeyAction;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8C776674-9910-4721-A764-97BDB791F719")
    IHutaoNativeHotKeyAction : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Update( 
            /* [in] */ HOT_KEY_MODIFIERS modifiers,
            /* [in] */ uint vk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetIsEnabled( 
            /* [out] */ BOOL *isEnabled) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIsEnabled( 
            /* [in] */ BOOL isEnabled) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeHotKeyActionVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeHotKeyAction * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeHotKeyAction * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeHotKeyAction * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeHotKeyAction * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeHotKeyAction * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeHotKeyAction * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeHotKeyAction, Update)
        HRESULT ( STDMETHODCALLTYPE *Update )( 
            IHutaoNativeHotKeyAction * This,
            /* [in] */ HOT_KEY_MODIFIERS modifiers,
            /* [in] */ uint vk);
        
        DECLSPEC_XFGVIRT(IHutaoNativeHotKeyAction, GetIsEnabled)
        HRESULT ( STDMETHODCALLTYPE *GetIsEnabled )( 
            IHutaoNativeHotKeyAction * This,
            /* [out] */ BOOL *isEnabled);
        
        DECLSPEC_XFGVIRT(IHutaoNativeHotKeyAction, SetIsEnabled)
        HRESULT ( STDMETHODCALLTYPE *SetIsEnabled )( 
            IHutaoNativeHotKeyAction * This,
            /* [in] */ BOOL isEnabled);
        
        END_INTERFACE
    } IHutaoNativeHotKeyActionVtbl;

    interface IHutaoNativeHotKeyAction
    {
        CONST_VTBL struct IHutaoNativeHotKeyActionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeHotKeyAction_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeHotKeyAction_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeHotKeyAction_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeHotKeyAction_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeHotKeyAction_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeHotKeyAction_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeHotKeyAction_Update(This,modifiers,vk)	\
    ( (This)->lpVtbl -> Update(This,modifiers,vk) ) 

#define IHutaoNativeHotKeyAction_GetIsEnabled(This,isEnabled)	\
    ( (This)->lpVtbl -> GetIsEnabled(This,isEnabled) ) 

#define IHutaoNativeHotKeyAction_SetIsEnabled(This,isEnabled)	\
    ( (This)->lpVtbl -> SetIsEnabled(This,isEnabled) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeHotKeyAction_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


