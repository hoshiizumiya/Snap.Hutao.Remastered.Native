#include "IHutaoNative.h"

// Intentionally empty. Implementation provided by HutaoNativeImpl (HutaoNativeImpl.cpp).
