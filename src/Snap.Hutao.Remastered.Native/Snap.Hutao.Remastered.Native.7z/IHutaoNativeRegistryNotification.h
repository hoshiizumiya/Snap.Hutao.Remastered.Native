#pragma once

#include "IHutaoNativeRegistryNotification_h.h"