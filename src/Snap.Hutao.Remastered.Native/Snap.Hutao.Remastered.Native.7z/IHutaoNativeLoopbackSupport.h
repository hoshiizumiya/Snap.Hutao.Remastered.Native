#pragma once

#include "IHutaoNativeLoopbackSupport_h.h"
#include <Windows.h>
#include <winrt/base.h>

