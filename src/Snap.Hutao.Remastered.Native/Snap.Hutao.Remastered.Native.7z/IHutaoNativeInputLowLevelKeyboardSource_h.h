

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeInputLowLevelKeyboardSource.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeInputLowLevelKeyboardSource_h_h__
#define __IHutaoNativeInputLowLevelKeyboardSource_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeInputLowLevelKeyboardSource_FWD_DEFINED__
#define __IHutaoNativeInputLowLevelKeyboardSource_FWD_DEFINED__
typedef interface IHutaoNativeInputLowLevelKeyboardSource IHutaoNativeInputLowLevelKeyboardSource;

#endif 	/* __IHutaoNativeInputLowLevelKeyboardSource_FWD_DEFINED__ */


/* header files for imported files */
#include "Types.h"
#include "IHutaoString.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeInputLowLevelKeyboardSource_INTERFACE_DEFINED__
#define __IHutaoNativeInputLowLevelKeyboardSource_INTERFACE_DEFINED__

/* interface IHutaoNativeInputLowLevelKeyboardSource */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeInputLowLevelKeyboardSource;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8628902F-835C-4293-8580-794EC9BCCB98")
    IHutaoNativeInputLowLevelKeyboardSource : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Attach( 
            /* [in] */ nint callback) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Detach( 
            /* [in] */ nint callback) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeInputLowLevelKeyboardSourceVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeInputLowLevelKeyboardSource * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeInputLowLevelKeyboardSource * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeInputLowLevelKeyboardSource * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeInputLowLevelKeyboardSource * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeInputLowLevelKeyboardSource * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeInputLowLevelKeyboardSource * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeInputLowLevelKeyboardSource, Attach)
        HRESULT ( STDMETHODCALLTYPE *Attach )( 
            IHutaoNativeInputLowLevelKeyboardSource * This,
            /* [in] */ nint callback);
        
        DECLSPEC_XFGVIRT(IHutaoNativeInputLowLevelKeyboardSource, Detach)
        HRESULT ( STDMETHODCALLTYPE *Detach )( 
            IHutaoNativeInputLowLevelKeyboardSource * This,
            /* [in] */ nint callback);
        
        END_INTERFACE
    } IHutaoNativeInputLowLevelKeyboardSourceVtbl;

    interface IHutaoNativeInputLowLevelKeyboardSource
    {
        CONST_VTBL struct IHutaoNativeInputLowLevelKeyboardSourceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeInputLowLevelKeyboardSource_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeInputLowLevelKeyboardSource_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeInputLowLevelKeyboardSource_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeInputLowLevelKeyboardSource_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeInputLowLevelKeyboardSource_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeInputLowLevelKeyboardSource_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeInputLowLevelKeyboardSource_Attach(This,callback)	\
    ( (This)->lpVtbl -> Attach(This,callback) ) 

#define IHutaoNativeInputLowLevelKeyboardSource_Detach(This,callback)	\
    ( (This)->lpVtbl -> Detach(This,callback) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeInputLowLevelKeyboardSource_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


