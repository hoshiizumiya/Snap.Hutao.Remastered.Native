#pragma once

#include "IHutaoNativeHotKeyAction_h.h"