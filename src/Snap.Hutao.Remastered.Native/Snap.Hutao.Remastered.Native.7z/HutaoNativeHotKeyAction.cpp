#include "HutaoNativeHotKeyAction.h"
#include <Windows.h>

using namespace winrt;

namespace
{
    const wchar_t* WINDOW_CLASS_NAME = L"HutaoNativeHotKeyActionWindowClass";
    const UINT WM_HOTKEY_MESSAGE = WM_APP + 2;
}

UINT HutaoNativeHotKeyAction::s_nextHotKeyId = 0x4000; // 从0x4000开始，避免与系统热键冲突

HutaoNativeHotKeyAction::HutaoNativeHotKeyAction()
    : m_modifiers(static_cast<HOT_KEY_MODIFIERS>(0))
    , m_vk(0)
    , m_enabled(false)
    , m_hotKeyId(0)
    , m_hWnd(nullptr)
{
    // 生成唯一的热键ID
    m_hotKeyId = static_cast<int>(++s_nextHotKeyId);
}

HutaoNativeHotKeyAction::~HutaoNativeHotKeyAction()
{
    SetIsEnabled(FALSE);
    if (m_hWnd != nullptr)
    {
        DestroyWindow(m_hWnd);
        m_hWnd = nullptr;
    }
}

ATOM HutaoNativeHotKeyAction::RegisterWindowClass()
{
    WNDCLASSEXW wc = { 0 };
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = &HutaoNativeHotKeyAction::WndProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.lpszClassName = WINDOW_CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    
    return RegisterClassExW(&wc);
}

HWND HutaoNativeHotKeyAction::CreateMessageWindow()
{
    static ATOM classAtom = RegisterWindowClass();
    if (classAtom == 0)
    {
        return nullptr;
    }

    HWND hWnd = CreateWindowExW(
        0,
        WINDOW_CLASS_NAME,
        L"HutaoNativeHotKeyActionMessageWindow",
        WS_OVERLAPPED,
        0, 0, 0, 0,
        nullptr,
        nullptr,
        GetModuleHandle(nullptr),
        this // 将this指针传递给窗口
    );

    return hWnd;
}

LRESULT CALLBACK HutaoNativeHotKeyAction::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (message == WM_CREATE)
    {
        CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
        SetWindowLongPtrW(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pCreate->lpCreateParams));
        return 0;
    }

    HutaoNativeHotKeyAction* pThis = reinterpret_cast<HutaoNativeHotKeyAction*>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));
    if (pThis != nullptr)
    {
        if (message == WM_HOTKEY)
        {
            // 处理热键消息
            // 这里可以添加热键被触发时的处理逻辑
            return 0;
        }
    }

    return DefWindowProcW(hWnd, message, wParam, lParam);
}

void HutaoNativeHotKeyAction::UnregisterHotKey()
{
    if (m_hWnd != nullptr && m_hotKeyId != 0)
    {
        ::UnregisterHotKey(m_hWnd, m_hotKeyId);
    }
}

void HutaoNativeHotKeyAction::RegisterHotKey()
{
    if (m_hWnd == nullptr || m_hotKeyId == 0 || m_vk == 0)
    {
        return;
    }

    // 将HOT_KEY_MODIFIERS转换为Windows热键修饰符
    UINT winModifiers = 0;
    if (m_modifiers & ModALT) winModifiers |= ModALT;
    if (m_modifiers & ModCONTROL) winModifiers |= ModCONTROL;
    if (m_modifiers & MOD_SHIFT) winModifiers |= MOD_SHIFT;
    if (m_modifiers & MOD_WIN) winModifiers |= MOD_WIN;
    if (m_modifiers & MOD_NOREPEAT) winModifiers |= MOD_NOREPEAT;

    ::RegisterHotKey(m_hWnd, m_hotKeyId, winModifiers, m_vk);
}

HRESULT STDMETHODCALLTYPE HutaoNativeHotKeyAction::Update(HOT_KEY_MODIFIERS modifiers, uint vk)
{
    bool wasEnabled = m_enabled;
    
    if (wasEnabled)
    {
        UnregisterHotKey();
    }

    m_modifiers = modifiers;
    m_vk = vk;

    if (wasEnabled)
    {
        RegisterHotKey();
    }

    return S_OK;
}

HRESULT STDMETHODCALLTYPE HutaoNativeHotKeyAction::GetIsEnabled(BOOL* isEnabled)
{
    if (isEnabled == nullptr)
    {
        return E_POINTER;
    }

    *isEnabled = m_enabled ? TRUE : FALSE;
    return S_OK;
}

HRESULT STDMETHODCALLTYPE HutaoNativeHotKeyAction::SetIsEnabled(BOOL isEnabled)
{
    bool newEnabled = (isEnabled != FALSE);

    if (newEnabled == m_enabled)
    {
        return S_OK; // 状态没有变化
    }

    if (newEnabled)
    {
        // 启用热键
        if (m_hWnd == nullptr)
        {
            m_hWnd = CreateMessageWindow();
            if (m_hWnd == nullptr)
            {
                return HRESULT_FROM_WIN32(GetLastError());
            }
        }

        if (m_vk != 0)
        {
            RegisterHotKey();
        }
    }
    else
    {
        // 禁用热键
        UnregisterHotKey();
    }

    m_enabled = newEnabled;
    return S_OK;
}
