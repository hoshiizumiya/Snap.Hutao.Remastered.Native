

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNative.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        EXTERN_C __declspec(selectany) const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif // !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IHutaoNativePrivate,0x1A6980D9,0xEB36,0x4E3E,0x86,0xE7,0x36,0x65,0xC5,0x7C,0x6E,0x8D);


MIDL_DEFINE_GUID(IID, IID_IHutaoPrivate2,0x4E5D37CF,0x5F38,0x4FF2,0x90,0x59,0xDF,0x39,0xCA,0x69,0x63,0x65);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative,0xD00F73FF,0xA1C7,0x4091,0x8C,0xB6,0xD9,0x09,0x91,0xDD,0x40,0xCB);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative2,0x338487EE,0x9592,0x4171,0x89,0xDD,0x1E,0x6B,0x9E,0xDB,0x2C,0x8E);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative3,0x135FACE1,0x3184,0x4D12,0xB4,0xD0,0x21,0xFF,0xB6,0xA8,0x8D,0x25);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative4,0x27942FBE,0x322F,0x4157,0x9B,0x8C,0xA3,0x8F,0xDB,0x82,0x7B,0x05);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative5,0x7B4D20F1,0x4DAD,0x492E,0x84,0x85,0xB4,0x70,0x1A,0x2E,0xD1,0x9B);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative6,0xB68CABFA,0xC55A,0x49FA,0x8C,0x51,0x21,0x61,0x5C,0x59,0x4E,0x2B);


MIDL_DEFINE_GUID(IID, IID_IHutaoNative7,0xB7A49A20,0xD9E2,0x43FD,0x96,0x37,0xE8,0x01,0x90,0x44,0x3A,0xBE);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



