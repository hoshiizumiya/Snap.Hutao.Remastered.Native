#pragma once

#include <Windows.h>

struct HutaoPrivateWindowsVersion {
    UINT major;
    UINT minor;
    UINT build;
    UINT revision;
};
