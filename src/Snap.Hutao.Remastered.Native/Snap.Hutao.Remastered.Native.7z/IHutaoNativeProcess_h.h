

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for IHutaoNativeProcess.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __IHutaoNativeProcess_h_h__
#define __IHutaoNativeProcess_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

#ifndef __IHutaoNativeProcess_FWD_DEFINED__
#define __IHutaoNativeProcess_FWD_DEFINED__
typedef interface IHutaoNativeProcess IHutaoNativeProcess;

#endif 	/* __IHutaoNativeProcess_FWD_DEFINED__ */


/* header files for imported files */
#include "Types.h"
#include "IHutaoString.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IHutaoNativeProcess_INTERFACE_DEFINED__
#define __IHutaoNativeProcess_INTERFACE_DEFINED__

/* interface IHutaoNativeProcess */
/* [object][uuid] */ 


EXTERN_C const IID IID_IHutaoNativeProcess;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("13A2B1A2-03CB-46E1-AED5-6AFEA2DFFB39")
    IHutaoNativeProcess : public IInspectable
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Start( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ResumeMainThread( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE WaitForExit( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Kill( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [out] */ uint *id) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetProcessHandle( 
            /* [out] */ HANDLE *hProcess) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetMainWindowHandle( 
            /* [out] */ HWND *hWnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetExitCodeProcess( 
            /* [out] */ BOOL *isRunning,
            /* [out] */ uint *exitCode) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IHutaoNativeProcessVtbl
    {
        BEGIN_INTERFACE
        
        DECLSPEC_XFGVIRT(IUnknown, QueryInterface)
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHutaoNativeProcess * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        DECLSPEC_XFGVIRT(IUnknown, AddRef)
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHutaoNativeProcess * This);
        
        DECLSPEC_XFGVIRT(IUnknown, Release)
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHutaoNativeProcess * This);
        
        DECLSPEC_XFGVIRT(IInspectable, GetIids)
        HRESULT ( STDMETHODCALLTYPE *GetIids )( 
            IHutaoNativeProcess * This,
            /* [out] */ ULONG *iidCount,
            /* [size_is][size_is][out] */ IID **iids);
        
        DECLSPEC_XFGVIRT(IInspectable, GetRuntimeClassName)
        HRESULT ( STDMETHODCALLTYPE *GetRuntimeClassName )( 
            IHutaoNativeProcess * This,
            /* [out] */ HSTRING *className);
        
        DECLSPEC_XFGVIRT(IInspectable, GetTrustLevel)
        HRESULT ( STDMETHODCALLTYPE *GetTrustLevel )( 
            IHutaoNativeProcess * This,
            /* [out] */ TrustLevel *trustLevel);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, Start)
        HRESULT ( STDMETHODCALLTYPE *Start )( 
            IHutaoNativeProcess * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, ResumeMainThread)
        HRESULT ( STDMETHODCALLTYPE *ResumeMainThread )( 
            IHutaoNativeProcess * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, WaitForExit)
        HRESULT ( STDMETHODCALLTYPE *WaitForExit )( 
            IHutaoNativeProcess * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, Kill)
        HRESULT ( STDMETHODCALLTYPE *Kill )( 
            IHutaoNativeProcess * This);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, GetId)
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            IHutaoNativeProcess * This,
            /* [out] */ uint *id);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, GetProcessHandle)
        HRESULT ( STDMETHODCALLTYPE *GetProcessHandle )( 
            IHutaoNativeProcess * This,
            /* [out] */ HANDLE *hProcess);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, GetMainWindowHandle)
        HRESULT ( STDMETHODCALLTYPE *GetMainWindowHandle )( 
            IHutaoNativeProcess * This,
            /* [out] */ HWND *hWnd);
        
        DECLSPEC_XFGVIRT(IHutaoNativeProcess, GetExitCodeProcess)
        HRESULT ( STDMETHODCALLTYPE *GetExitCodeProcess )( 
            IHutaoNativeProcess * This,
            /* [out] */ BOOL *isRunning,
            /* [out] */ uint *exitCode);
        
        END_INTERFACE
    } IHutaoNativeProcessVtbl;

    interface IHutaoNativeProcess
    {
        CONST_VTBL struct IHutaoNativeProcessVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHutaoNativeProcess_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IHutaoNativeProcess_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IHutaoNativeProcess_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IHutaoNativeProcess_GetIids(This,iidCount,iids)	\
    ( (This)->lpVtbl -> GetIids(This,iidCount,iids) ) 

#define IHutaoNativeProcess_GetRuntimeClassName(This,className)	\
    ( (This)->lpVtbl -> GetRuntimeClassName(This,className) ) 

#define IHutaoNativeProcess_GetTrustLevel(This,trustLevel)	\
    ( (This)->lpVtbl -> GetTrustLevel(This,trustLevel) ) 


#define IHutaoNativeProcess_Start(This)	\
    ( (This)->lpVtbl -> Start(This) ) 

#define IHutaoNativeProcess_ResumeMainThread(This)	\
    ( (This)->lpVtbl -> ResumeMainThread(This) ) 

#define IHutaoNativeProcess_WaitForExit(This)	\
    ( (This)->lpVtbl -> WaitForExit(This) ) 

#define IHutaoNativeProcess_Kill(This)	\
    ( (This)->lpVtbl -> Kill(This) ) 

#define IHutaoNativeProcess_GetId(This,id)	\
    ( (This)->lpVtbl -> GetId(This,id) ) 

#define IHutaoNativeProcess_GetProcessHandle(This,hProcess)	\
    ( (This)->lpVtbl -> GetProcessHandle(This,hProcess) ) 

#define IHutaoNativeProcess_GetMainWindowHandle(This,hWnd)	\
    ( (This)->lpVtbl -> GetMainWindowHandle(This,hWnd) ) 

#define IHutaoNativeProcess_GetExitCodeProcess(This,isRunning,exitCode)	\
    ( (This)->lpVtbl -> GetExitCodeProcess(This,isRunning,exitCode) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IHutaoNativeProcess_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


